# Database settings
MY_SECRET_KEY = ''

dbaccess_postgres = {
}

dbaccess_oracle_doma = {
}

dbaccess_oracle_atlas = {
}

dbaccess = dbaccess_oracle_atlas

#aws
aws = {
}

# ... and other settings typical for local.py